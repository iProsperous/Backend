import { argv, exit } from 'node:process';
import * as path from 'node:path';

let a = argv[2];
let b = argv[3];
let c = argv[4];
let D,x1,x2 = 0;

if (argv[2]!==0) {
D=b*b-4*a*c;
    if (D>0) {
        x1=(-b+Math.sqrt(D))/2*a;
        x2=(-b-Math.sqrt(D))/2*a;
        console.log(`Уравнение имеет два корня ${x1} , ${x2}`);
    }
    else if (D===0) {
        x1=-b/2*a;
        console.log(`Уравнение имеет один корень ${x1}`);
    }
    else {
        console.log(`Уравнение не имеет решения`);
    }
    exit(0);
}




